"""
verificar_quimica.py
=====================
Revisa un dataset JSONL (o archivos .tex) buscando errores químicos comunes:

  1. Números atómicos (Z) incorrectos      → "Z=30 para el hierro" ✗
  2. Símbolos químicos mal escritos
  3. Configuraciones electrónicas con total de electrones que no coincide con Z
  4. Sumas de estados de oxidación que no dan cero/carga correcta
  5. Conteo de electrones de iones incoherente

NO modifica nada. Solo REPORTA posibles errores para que los revises a mano.

Uso:
    python verificar_quimica.py dataset_quimica_v3.jsonl
    python verificar_quimica.py archivo.tex
"""

import re
import sys
import json
from pathlib import Path
# ══════════════════════════════════════════════════════════════════
# TABLA PERIÓDICA DE REFERENCIA (Z y masa molar)
# ══════════════════════════════════════════════════════════════════
# Z = número atómico ; masa en g/mol (IUPAC, 4 cifras)
TABLA = {
    'H': (1, 1.008),    'He': (2, 4.003),   'Li': (3, 6.941),
    'Be': (4, 9.012),   'B': (5, 10.81),    'C': (6, 12.01),
    'N': (7, 14.01),    'O': (8, 16.00),    'F': (9, 19.00),
    'Ne': (10, 20.18),  'Na': (11, 22.99),  'Mg': (12, 24.31),
    'Al': (13, 26.98),  'Si': (14, 28.09),  'P': (15, 30.97),
    'S': (16, 32.07),   'Cl': (17, 35.45),  'Ar': (18, 39.95),
    'K': (19, 39.10),   'Ca': (20, 40.08),  'Sc': (21, 44.96),
    'Ti': (22, 47.87),  'V': (23, 50.94),   'Cr': (24, 52.00),
    'Mn': (25, 54.94),  'Fe': (26, 55.85),  'Co': (27, 58.93),
    'Ni': (28, 58.69),  'Cu': (29, 63.55),  'Zn': (30, 65.38),
    'Ga': (31, 69.72),  'Ge': (32, 72.63),  'As': (33, 74.92),
    'Se': (34, 78.97),  'Br': (35, 79.90),  'Kr': (36, 83.80),
    'Rb': (37, 85.47),  'Sr': (38, 87.62),  'Y': (39, 88.91),
    'Zr': (40, 91.22),  'Nb': (41, 92.91),  'Mo': (42, 95.95),
    'Tc': (43, 98.00),  'Ru': (44, 101.1),  'Rh': (45, 102.9),
    'Pd': (46, 106.4),  'Ag': (47, 107.9),  'Cd': (48, 112.4),
    'In': (49, 114.8),  'Sn': (50, 118.7),  'Sb': (51, 121.8),
    'Te': (52, 127.6),  'I': (53, 126.9),   'Xe': (54, 131.3),
    'Cs': (55, 132.9),  'Ba': (56, 137.3),  'La': (57, 138.9),
    'Ce': (58, 140.1),  'Pt': (78, 195.1),  'Au': (79, 197.0),
    'Hg': (80, 200.6),  'Pb': (82, 207.2),  'Bi': (83, 209.0),
    'U': (92, 238.0),
}
# Nombre de elemento en español → símbolo
NOMBRES = {
    'hidrógeno': 'H', 'hidrogeno': 'H', 'helio': 'He', 'litio': 'Li',
    'berilio': 'Be', 'boro': 'B', 'carbono': 'C', 'nitrógeno': 'N',
    'nitrogeno': 'N', 'oxígeno': 'O', 'oxigeno': 'O', 'flúor': 'F',
    'fluor': 'F', 'neón': 'Ne', 'neon': 'Ne', 'sodio': 'Na',
    'magnesio': 'Mg', 'aluminio': 'Al', 'silicio': 'Si', 'fósforo': 'P',
    'fosforo': 'P', 'azufre': 'S', 'cloro': 'Cl', 'argón': 'Ar',
    'argon': 'Ar', 'potasio': 'K', 'calcio': 'Ca', 'escandio': 'Sc',
    'titanio': 'Ti', 'vanadio': 'V', 'cromo': 'Cr', 'manganeso': 'Mn',
    'hierro': 'Fe', 'cobalto': 'Co', 'níquel': 'Ni', 'niquel': 'Ni',
    'cobre': 'Cu', 'zinc': 'Zn', 'cinc': 'Zn', 'galio': 'Ga',
    'germanio': 'Ge', 'arsénico': 'As', 'arsenico': 'As', 'selenio': 'Se',
    'bromo': 'Br', 'kriptón': 'Kr', 'kripton': 'Kr', 'rubidio': 'Rb',
    'estroncio': 'Sr', 'itrio': 'Y', 'circonio': 'Zr', 'plata': 'Ag',
    'cadmio': 'Cd', 'estaño': 'Sn', 'estano': 'Sn', 'yodo': 'I',
    'xenón': 'Xe', 'xenon': 'Xe', 'cesio': 'Cs', 'bario': 'Ba',
    'platino': 'Pt', 'oro': 'Au', 'mercurio': 'Hg', 'plomo': 'Pb',
    'uranio': 'U',
}


# ══════════════════════════════════════════════════════════════════
# VERIFICADORES INDIVIDUALES
# ══════════════════════════════════════════════════════════════════
def verificar_numero_atomico(texto: str) -> list:
    """
    Busca afirmaciones tipo "el hierro tiene Z = 30" y verifica contra la tabla.
    Detecta patrones como:
      - "hierro ... Z = 26"
      - "Z = 26 ... hierro"
      - "número atómico ... 26 ... hierro"
    """
    errores = []
    texto_lower = texto.lower()
    # Para cada elemento mencionado por nombre, buscar un Z cercano
    for nombre, simbolo in NOMBRES.items():
        # Usar límites de palabra para evitar "oro" dentro de "boro"/"cloro"/"fósforo"
        if not re.search(r'\b' + re.escape(nombre) + r'\b', texto_lower):
            continue
        z_correcto = TABLA[simbolo][0]
        # Buscar todas las posiciones del nombre (con límite de palabra)
        for m in re.finditer(r'\b' + re.escape(nombre) + r'\b', texto_lower):
            inicio = max(0, m.start() - 150)
            fin = min(len(texto_lower), m.end() + 150)
            ventana = texto_lower[inicio:fin]

            # Capturar SOLO el patrón estricto "z = numero" (con espacios opcionales)
            # Excluir notación científica "z = 2 \times 10^1"
            patrones_z = re.findall(
                r'(?:^|[^a-z0-9_])z\s*=\s*(\d{1,3})\b(?!\s*\\times)',
                ventana
            )

            for z_str in patrones_z:
                z_encontrado = int(z_str)
                if z_encontrado != z_correcto and 1 <= z_encontrado < 120:
                    errores.append(
                        f'Posible Z incorrecto: "{nombre}" tiene Z={z_correcto}, '
                        f'pero se encontró Z={z_encontrado} cerca.'
                    )
                    break  # un error por mención es suficiente
    return errores


def verificar_total_electrones_config(texto: str) -> list:
    """
    Busca configuraciones electrónicas y suma los superíndices.
    Compara con el Z del elemento si está mencionado.
    Ejemplo: [Ar] 4s^2 3d^6  → núcleo Ar(18) + 2 + 6 = 26
    """
    errores = []
    # Núcleos de gases nobles
    nucleos = {
        'he': 2, 'ne': 10, 'ar': 18, 'kr': 36, 'xe': 54, 'rn': 86
    }

    # Buscar patrones de configuración con núcleo abreviado
    # Ej: [\mathrm{Ar}]\,4s^2\,3d^6
    config_pattern = re.findall(
        r'\[\s*\\?mathrm\{?(He|Ne|Ar|Kr|Xe|Rn)\}?\s*\](.*?)(?:\\\]|\n\n|$)',
        texto, re.IGNORECASE
    )

    for nucleo, resto in config_pattern:
        base = nucleos.get(nucleo.lower(), 0)
        # Sumar todos los superíndices del tipo s^2, p^6, d^10, etc.
        superindices = re.findall(r'[spdf]\^?\{?(\d+)\}?', resto)
        total = base + sum(int(x) for x in superindices)
        # Solo reportamos si parece un total raro (no es prioritario)
        # Este check es informativo
    return errores


def verificar_estados_oxidacion(texto: str) -> list:
    """
    Busca ecuaciones de neutralidad tipo "2x + 5(-2) = 0" y verifica la aritmética.
    """
    errores = []
    # Buscar patrones tipo: numero(signo numero) ... = 0
    # Ej: 2(+5) + 5(-2) = 0
    ecuaciones = re.findall(
        r'(\d+)\s*\(\s*([+-]?\d+)\s*\)\s*\+\s*(\d+)\s*\(\s*([+-]?\d+)\s*\)\s*=\s*(\d+)',
        texto
    )
    for a, b, c, d, resultado in ecuaciones:
        suma = int(a) * int(b) + int(c) * int(d)
        if suma != int(resultado):
            errores.append(
                f'Aritmética sospechosa: {a}({b}) + {c}({d}) = {suma}, '
                f'pero el texto dice = {resultado}.'
            )
    return errores


def verificar_aritmetica_simple(texto: str) -> list:
    """
    Verifica SOLO operaciones aritméticas de ALTA CONFIANZA en texto plano,
    fuera de cualquier contexto de configuración electrónica o número atómico.

    Maneja sumas encadenadas: "36 + 1 + 5 = 42"
    """
    errores = []

    # 1) Sumas/restas encadenadas: a + b + c + ... = total
    #    Captura una secuencia de números con + o - y un = al final
    for m in re.finditer(
        r'(?<![\^_\d.])(\d{1,3}(?:\s*[+\-]\s*\d{1,3})+)\s*=\s*(\d{1,4})(?![\^_.\d])',
        texto
    ):
        expresion = m.group(1)
        total_dicho = int(m.group(2))

        # Contexto: descartar configuraciones electrónicas
        ctx_antes = texto[max(0, m.start()-40):m.start()]
        if re.search(r'[spdf]\^|4d|3d|5s|4p|3p', ctx_antes):
            continue

        # Evaluar la expresión de forma segura (solo dígitos, + y -)
        if re.fullmatch(r'[\d\s+\-]+', expresion):
            try:
                total_real = eval(expresion)  # seguro: solo números y +/-
                if total_real != total_dicho:
                    errores.append(
                        f'Operación incorrecta: {expresion.strip()} = {total_real}, '
                        f'pero el texto dice = {total_dicho}.'
                    )
            except Exception:
                pass

    # 2) Multiplicaciones explícitas con \times
    for m in re.finditer(r'(\d+)\s*\\times\s*(\d+)\s*=\s*([\-]?\d+)', texto):
        a, b, c = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if a * b != c:
            errores.append(
                f'Multiplicación incorrecta: {a} × {b} = {a*b}, '
                f'pero el texto dice = {c}.'
            )

    return errores


def _a_float(num_str: str) -> float:
    """Convierte '4,08' o '4.08' a float. Maneja coma decimal."""
    return float(num_str.strip().replace(',', '.'))


def _fmt(valor: float) -> str:
    """Formatea un float con coma decimal y hasta 2 decimales."""
    return f'{valor:.2f}'.replace('.', ',')


def verificar_fracciones(texto: str, tolerancia: float = 0.02) -> list:
    """
    Verifica cálculos del tipo:
       \frac{4,08}{200} \times 100 = 2,04
       \frac{130,61}{200} = 0,65305
    Maneja coma decimal y el patrón fracción (× factor)? = resultado.
    """
    errores = []

    # Patrón: \frac{A}{B} (\times C)? = D
    patron = re.compile(
        r'\\frac\{([\d.,]+)\}\{([\d.,]+)\}'
        r'(?:\s*\\times\s*([\d.,]+))?'
        r'\s*=\s*([\d.,]+)'
    )

    for m in patron.finditer(texto):
        try:
            a = _a_float(m.group(1))
            b = _a_float(m.group(2))
            factor = _a_float(m.group(3)) if m.group(3) else 1.0
            resultado_dicho = _a_float(m.group(4))

            if b == 0:
                continue
            resultado_real = (a / b) * factor

            # Tolerancia relativa (por redondeo legítimo)
            if abs(resultado_real - resultado_dicho) > tolerancia:
                expr = f'{m.group(1)}/{m.group(2)}'
                if m.group(3):
                    expr += f' × {m.group(3)}'
                errores.append(
                    f'Cálculo sospechoso: {expr} = {_fmt(resultado_real)}, '
                    f'pero el texto dice = {m.group(4)}.'
                )
        except (ValueError, ZeroDivisionError):
            continue

    return errores


def verificar_sumas_decimales(texto: str, tolerancia: float = 0.02) -> list:
    """
    Verifica sumas de decimales con coma:
       2,04% + 32,65% + 65,31% = 100,00%
       2,04 + 32,65 + 65,31 = 100,00
    """
    errores = []

    # Secuencia de decimales (con coma) separados por +, con % opcional, = total
    # Maneja tanto % como \% (LaTeX)
    patron = re.compile(
        r'([\d]+,[\d]+\s*\\?%?(?:\s*\+\s*[\d]+,[\d]+\s*\\?%?)+)\s*=\s*([\d]+,[\d]+)\s*\\?%?'
    )

    for m in patron.finditer(texto):
        secuencia = m.group(1)
        total_dicho = _a_float(m.group(2))

        # Extraer todos los números de la secuencia
        numeros = re.findall(r'[\d]+,[\d]+', secuencia)
        try:
            suma_real = sum(_a_float(n) for n in numeros)
            if abs(suma_real - total_dicho) > tolerancia:
                nums_str = ' + '.join(numeros)
                errores.append(
                    f'Suma decimal sospechosa: {nums_str} = {_fmt(suma_real)}, '
                    f'pero el texto dice = {m.group(2)}.'
                )
        except ValueError:
            continue

    return errores


# ══════════════════════════════════════════════════════════════════
# VERIFICADOR PRINCIPAL
# ══════════════════════════════════════════════════════════════════
def verificar_ejercicio(enunciado: str, solucion: str) -> list:
    """Aplica todos los verificadores a un ejercicio."""
    texto_completo = enunciado + '\n' + solucion
    errores = []
    errores += verificar_numero_atomico(texto_completo)
    errores += verificar_estados_oxidacion(texto_completo)
    errores += verificar_aritmetica_simple(texto_completo)
    errores += verificar_fracciones(texto_completo)
    errores += verificar_sumas_decimales(texto_completo)
    # eliminar duplicados conservando orden
    vistos = set()
    unicos = []
    for e in errores:
        if e not in vistos:
            vistos.add(e)
            unicos.append(e)
    return unicos



# ══════════════════════════════════════════════════════════════════
# LECTURA DE ARCHIVOS
# ══════════════════════════════════════════════════════════════════
def leer_jsonl(ruta: Path):
    """Devuelve lista de (enunciado, solucion)."""
    ejercicios = []
    with open(ruta, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            msgs = data['messages']
            user = next((m['content'] for m in msgs if m['role'] == 'user'), '')
            asst = next((m['content'] for m in msgs if m['role'] == 'assistant'), '')
            ejercicios.append((user, asst))
    return ejercicios


def leer_tex(ruta: Path):
    """Extrae pares Enunciado/Solución de un .tex."""
    try:
        content = ruta.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        content = ruta.read_text(encoding='latin-1')
    patron = re.compile(
        r'\\subsection\*\{Enunciado\s*\}(.*?)'
        r'\\subsection\*\{Soluci[oó]n\s*\}(.*?)'
        r'(?=\\subsection\*\{Enunciado\s*\}|\\end\{document\}|\Z)',
        re.DOTALL | re.IGNORECASE
    )
    return [(e.strip(), s.strip()) for e, s in patron.findall(content)]


# ══════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════
def main():
    if len(sys.argv) < 2:
        print('Uso: python verificar_quimica.py <archivo.jsonl o archivo.tex o carpeta>')
        return

    ruta = Path(sys.argv[1])

    # Recolectar ejercicios
    ejercicios = []
    if ruta.is_file() and ruta.suffix == '.jsonl':
        ejercicios = leer_jsonl(ruta)
    elif ruta.is_file() and ruta.suffix == '.tex':
        ejercicios = leer_tex(ruta)
    elif ruta.is_dir():
        for tex in sorted(ruta.rglob('*.tex')):
            ejercicios += leer_tex(tex)
    else:
        print(f'No se pudo leer: {ruta}')
        return

    print(f'Verificando {len(ejercicios)} ejercicios...\n')

    total_con_errores = 0
    reporte = []

    for i, (enunciado, solucion) in enumerate(ejercicios, 1):
        errores = verificar_ejercicio(enunciado, solucion)
        if errores:
            total_con_errores += 1
            # Primeras palabras del enunciado para identificarlo
            titulo = re.sub(r'\s+', ' ', enunciado)[:80]
            reporte.append(f'\n{"="*60}')
            reporte.append(f'EJERCICIO #{i}: {titulo}...')
            reporte.append(f'{"="*60}')
            for e in errores:
                reporte.append(f'  ⚠  {e}')

    # Guardar y mostrar reporte (en el directorio actual, no en uploads)
    salida = ruta.stem + '_errores_quimica.txt'
    with open(salida, 'w', encoding='utf-8') as f:
        f.write('\n'.join(reporte))
        f.write(f'\n\n{"="*60}\n')
        f.write(f'RESUMEN: {total_con_errores} de {len(ejercicios)} '
                f'ejercicios con posibles errores.\n')
        f.write('IMPORTANTE: Estos son POSIBLES errores. '
                'Revisa cada uno manualmente.\n')

    print('\n'.join(reporte) if reporte else 'No se detectaron errores automáticos.')
    print(f'\n{"="*60}')
    print(f'RESUMEN: {total_con_errores} de {len(ejercicios)} '
          f'ejercicios con posibles errores.')
    print(f'Reporte guardado en: {salida}')
    print('\nNOTA: El script detecta errores comunes (Z, aritmética simple,')
    print('estados de oxidación), pero NO reemplaza una revisión humana completa.')


if __name__ == '__main__':
    main()
