"""
extraer_sospechosos.py
======================
Extrae los ejercicios sospechosos del dataset a UN solo archivo
para revisión manual rápida.

Uso:
    python extraer_sospechosos.py
"""

import re
from pathlib import Path

# Números de ejercicio que QUEREMOS revisar (Grupo B y C según el reporte)
NUMEROS_A_REVISAR = {
    # Grupo B - Sumas/multiplicaciones sospechosas
    10:  'Conversión de temperatura: "6 + 32 = 98"',
    249: 'Multiplicación: "100 × 100 = 40"',
    250: 'Multiplicación: "3 × 1 = 17"',
    255: 'Multiplicación: "23 × 100 = 23"',
    524: 'Suma: "9 + 28 = 100"',
    535: 'Suma: "9 + 71 = 125"',
    541: 'Suma: "7 + 48 = 159"',
    547: 'Suma: "9 + 28 = 100"',
    549: 'Suma: "2 + 254 = 461"',
    615: 'División: "75/100 = 445,5"',
    # Grupo C - Errores muy probables
    437: 'Masa molar: "2(14) + 4(16) = 72" (real es 92)',
    483: 'Masa molar: "2(52) + 7(16) = 294" (real es 216)',
    502: 'Estequiometría: "2(1) + 5(1) = 16" (real es 7)',
    614: 'Masa molar: "2(14) + 4(1) = 60" (real es 32)',
}


def main():
    carpeta = Path('.')
    archivos = sorted(carpeta.glob('*.tex'))

    # Recolectar todos los ejercicios en orden
    todos_ejercicios = []
    for archivo in archivos:
        try:
            contenido = archivo.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            contenido = archivo.read_text(encoding='latin-1')

        patron = re.compile(
            r'(\\subsection\*\{Enunciado\s*\}.*?)'
            r'(?=\\subsection\*\{Enunciado\s*\}|\\end\{document\}|\Z)',
            re.DOTALL | re.IGNORECASE
        )

        for m in patron.finditer(contenido):
            todos_ejercicios.append({
                'archivo': archivo.name,
                'texto': m.group(1).strip()
            })

    print(f'Total de ejercicios encontrados: {len(todos_ejercicios)}\n')

    # Extraer solo los sospechosos
    salida = []
    salida.append('=' * 70)
    salida.append('EJERCICIOS SOSPECHOSOS PARA REVISIÓN MANUAL')
    salida.append('=' * 70)
    salida.append(f'Total a revisar: {len(NUMEROS_A_REVISAR)} ejercicios')
    salida.append('=' * 70)
    salida.append('')

    encontrados = 0
    for numero in sorted(NUMEROS_A_REVISAR.keys()):
        if numero <= len(todos_ejercicios):
            ej = todos_ejercicios[numero - 1]
            error_descrito = NUMEROS_A_REVISAR[numero]

            salida.append('')
            salida.append('#' * 70)
            salida.append(f'# EJERCICIO #{numero}')
            salida.append(f'# Archivo:  {ej["archivo"]}')
            salida.append(f'# Posible error: {error_descrito}')
            salida.append('#' * 70)
            salida.append('')
            salida.append(ej['texto'])
            salida.append('')
            encontrados += 1

    archivo_salida = 'EJERCICIOS_A_REVISAR.txt'
    with open(archivo_salida, 'w', encoding='utf-8') as f:
        f.write('\n'.join(salida))

    print(f'✓ Extraídos {encontrados} ejercicios sospechosos.')
    print(f'✓ Guardados en: {archivo_salida}')
    print('')
    print('SIGUIENTE PASO:')
    print(f'  1. Abre {archivo_salida} en VSCode.')
    print('  2. Revisa cada ejercicio buscando el cálculo señalado.')
    print('  3. Si encuentras un error real, corrígelo en el archivo .tex original.')
    print('  4. Si el cálculo es correcto, es un falso positivo: déjalo así.')


if __name__ == '__main__':
    main()