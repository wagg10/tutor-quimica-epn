"""
convertir_dataset_final.py
==========================
Script DEFINITIVO para convertir archivos .tex a JSONL para fine-tuning.

ASUMIENDO QUE TUS EJERCICIOS YA TIENEN ESTA ESTRUCTURA EXACTA:

    \subsection*{Enunciado}
    [texto del ejercicio]
    \subsection*{Solución}
    \subsubsection*{1. Fundamento químico del problema}
    [contenido]
    \subsubsection*{2. Información proporcionada}
    [contenido]
    \subsubsection*{3. Lo que se debe determinar}
    [contenido]
    \subsubsection*{4. Relaciones químicas y expresiones necesarias}
    [contenido]
    \subsubsection*{5. Aplicación de los datos}
    [contenido]
    \subsubsection*{6. Resolución paso a paso}
    [contenido]
    \subsubsection*{7. Resultado obtenido}
    \[\boxed{resultado}\]
    \subsubsection*{8. Conclusión}
    [contenido]

USO:
    python convertir_dataset_final.py
    python convertir_dataset_final.py carpeta/
    python convertir_dataset_final.py archivo.tex
    python convertir_dataset_final.py . dataset_quimica_final.jsonl

SALIDA:
    dataset_quimica_final.jsonl   → listo para fine-tuning
    reporte_conversion.txt        → estadísticas detalladas
"""

import re
import json
import sys
from pathlib import Path


# ══════════════════════════════════════════════════════════════════════
# SYSTEM PROMPT
# ══════════════════════════════════════════════════════════════════════
SYSTEM_PROMPT = (
    "Eres un tutor académico de Química para estudiantes universitarios de la "
    "Escuela Politécnica Nacional. Respondes siempre en español, con estilo "
    "académico, claro y pedagógico.\n\n"
    "Para cada ejercicio o problema de química, estructuras tu respuesta usando "
    "EXACTAMENTE estos 8 encabezados en orden, sin excepción:\n\n"
    "### 1. Fundamento químico del problema\n"
    "### 2. Información proporcionada\n"
    "### 3. Lo que se debe determinar\n"
    "### 4. Relaciones químicas y expresiones necesarias\n"
    "### 5. Aplicación de los datos\n"
    "### 6. Resolución paso a paso\n"
    "### 7. Resultado obtenido\n"
    "### 8. Conclusión\n\n"
    "Reglas obligatorias:\n"
    "- Nunca omites ningún encabezado.\n"
    "- Nunca comienzas con frases introductorias.\n"
    "- No generas código Python ni pseudocódigo.\n"
    "- No usas \\begin{table}, \\begin{itemize}, \\begin{equation} "
    "ni entornos LaTeX de bloque.\n"
    "- Usas LaTeX solo para fórmulas con \\[ \\] o \\( \\).\n"
    "- En el encabezado 7 presentas el resultado en \\[\\boxed{...}\\].\n"
    "- No inventas datos ni condiciones que no estén en el enunciado."
)

# Los 8 encabezados esperados (en orden)
ENCABEZADOS_FIJOS = [
    "### 1. Fundamento químico del problema",
    "### 2. Información proporcionada",
    "### 3. Lo que se debe determinar",
    "### 4. Relaciones químicas y expresiones necesarias",
    "### 5. Aplicación de los datos",
    "### 6. Resolución paso a paso",
    "### 7. Resultado obtenido",
    "### 8. Conclusión",
]


# ══════════════════════════════════════════════════════════════════════
# LIMPIEZA DE LATEX
# ══════════════════════════════════════════════════════════════════════
def limpiar_latex(texto: str) -> str:
    """
    Elimina comandos LaTeX no deseados conservando el contenido matemático
    y químico. Convierte estructuras LaTeX a Markdown limpio.
    """

    # 1) Eliminar bloques TikZ (diagramas)
    texto = re.sub(
        r'\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}',
        '', texto, flags=re.DOTALL
    )

    # 2) Eliminar bloques de código fuente
    texto = re.sub(
        r'\\begin\{lstlisting\}.*?\\end\{lstlisting\}',
        '', texto, flags=re.DOTALL
    )
    texto = re.sub(
        r'\\begin\{minted\}.*?\\end\{minted\}',
        '', texto, flags=re.DOTALL
    )

    # 3) Eliminar tablas LaTeX completas
    texto = re.sub(
        r'\\begin\{table\*?\}.*?\\end\{table\*?\}',
        '', texto, flags=re.DOTALL
    )
    texto = re.sub(
        r'\\begin\{tabular\}.*?\\end\{tabular\}',
        '', texto, flags=re.DOTALL
    )

    # 4) Convertir itemize/enumerate a viñetas Markdown
    def extraer_items(match):
        contenido = match.group(1)
        items = re.findall(
            r'\\item\s*(.*?)(?=\\item|\Z)', contenido, re.DOTALL
        )
        return '\n'.join(
            '- ' + item.strip() for item in items if item.strip()
        )

    texto = re.sub(
        r'\\begin\{itemize\}(.*?)\\end\{itemize\}',
        extraer_items, texto, flags=re.DOTALL
    )
    texto = re.sub(
        r'\\begin\{enumerate\}(?:\[[^\]]*\])?(.*?)\\end\{enumerate\}',
        extraer_items, texto, flags=re.DOTALL
    )

    # 5) Eliminar entornos decorativos manteniendo el contenido
    for env in ['center', 'tcolorbox', 'minipage', 'figure', 'array']:
        texto = re.sub(rf'\\begin\{{{env}\}}(?:\[[^\]]*\])?', '', texto)
        texto = re.sub(rf'\\end\{{{env}\}}', '', texto)

    # 6) Convertir formato de texto
    texto = re.sub(r'\\textbf\{([^}]+)\}', r'**\1**', texto)
    texto = re.sub(r'\\textit\{([^}]+)\}', r'*\1*', texto)
    texto = re.sub(r'\\emph\{([^}]+)\}', r'*\1*', texto)
    texto = re.sub(r'\\underline\{([^}]+)\}', r'_\1_', texto)

    # 7) Normalizar \si{} → \mathrm{}
    texto = re.sub(r'\\si\{([^}]*)\}', r'\\mathrm{\1}', texto)

    # 8) Eliminar comandos visuales puros
    for cmd in [
        r'\centering', r'\newpage', r'\noindent', r'\clearpage',
        r'\hline', r'\toprule', r'\midrule', r'\bottomrule',
        r'\medskip', r'\bigskip', r'\smallskip',
    ]:
        texto = texto.replace(cmd, '')
    texto = re.sub(r'\\vspace\{[^}]*\}', '', texto)
    texto = re.sub(r'\\hspace\{[^}]*\}', '', texto)
    texto = re.sub(r'\\resizebox\{[^}]*\}\{[^}]*\}', '', texto)

    # 9) Eliminar \caption{...} y \label{...}
    texto = re.sub(r'\\caption\{[^}]*\}', '', texto)
    texto = re.sub(r'\\label\{[^}]*\}', '', texto)

    # 10) Normalizar espacios y saltos de línea
    texto = re.sub(r'[ \t]+', ' ', texto)
    texto = re.sub(r'\n[ \t]+\n', '\n\n', texto)
    texto = re.sub(r'\n{3,}', '\n\n', texto)

    return texto.strip()


# ══════════════════════════════════════════════════════════════════════
# CONVERSIÓN DE SOLUCIÓN: subsubsecciones → encabezados markdown ###
# ══════════════════════════════════════════════════════════════════════
def convertir_solucion(solucion_raw: str) -> str:
    """
    Convierte el cuerpo de la solución reemplazando cada
    \\subsubsection*{N. Título} por ### N. Título (markdown).

    ASUME que la solución ya tiene los 8 nombres correctos:
        1. Fundamento químico del problema
        2. Información proporcionada
        ...
        8. Conclusión
    """
    # Reemplazar \subsubsection*{...} → ### ...
    solucion = re.sub(
        r'\\subsubsection\*\{([^}]+)\}',
        r'### \1',
        solucion_raw
    )

    # Limpiar el resto de LaTeX
    solucion = limpiar_latex(solucion)

    return solucion


# ══════════════════════════════════════════════════════════════════════
# EXTRACCIÓN DE PARES ENUNCIADO/SOLUCIÓN
# ══════════════════════════════════════════════════════════════════════
def extraer_registros(content: str):
    """
    Extrae todos los pares Enunciado/Solución de un archivo LaTeX.
    """
    patron = re.compile(
        r'\\subsection\*\{Enunciado\s*\}(.*?)'
        r'\\subsection\*\{Soluci[oó]n\s*\}(.*?)'
        r'(?=\\subsection\*\{Enunciado\s*\}|\\end\{document\}|\Z)',
        re.DOTALL | re.IGNORECASE
    )

    registros = []
    for enunciado_raw, solucion_raw in patron.findall(content):
        enunciado = limpiar_latex(enunciado_raw)
        solucion = convertir_solucion(solucion_raw)

        if not enunciado.strip() or not solucion.strip():
            continue

        registros.append((enunciado, solucion))

    return registros


# ══════════════════════════════════════════════════════════════════════
# VERIFICACIÓN DE CALIDAD
# ══════════════════════════════════════════════════════════════════════
def verificar_calidad(solucion: str) -> dict:
    """Verifica que la solución tenga el formato correcto."""
    checks = {
        'tiene_8_encabezados': all(enc in solucion for enc in ENCABEZADOS_FIJOS),
        'tiene_codigo_python': 'import ' in solucion or 'def plot_' in solucion,
        'tiene_latex_prohibido': any(
            cmd in solucion for cmd in [
                r'\begin{table}', r'\begin{itemize}',
                r'\begin{equation}', r'\begin{tabular}'
            ]
        ),
        'tiene_boxed': r'\boxed' in solucion,
    }
    # Contar cuántos de los 8 encabezados están presentes
    checks['n_encabezados_presentes'] = sum(
        1 for enc in ENCABEZADOS_FIJOS if enc in solucion
    )
    return checks


# ══════════════════════════════════════════════════════════════════════
# PROCESAMIENTO POR ARCHIVO
# ══════════════════════════════════════════════════════════════════════
def procesar_archivo(ruta_tex: Path, outfile, reporte_lines: list) -> int:
    """Procesa un archivo .tex y escribe los registros JSONL en outfile."""
    try:
        content = ruta_tex.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        try:
            content = ruta_tex.read_text(encoding='latin-1')
        except Exception as e:
            reporte_lines.append(f'  [ERROR lectura] {e}')
            return 0

    registros = extraer_registros(content)
    count = 0
    incompletos = []

    for i, (enunciado, solucion) in enumerate(registros, 1):
        checks = verificar_calidad(solucion)

        record = {
            "messages": [
                {"role": "system",    "content": SYSTEM_PROMPT},
                {"role": "user",      "content": enunciado},
                {"role": "assistant", "content": solucion},
            ]
        }
        outfile.write(json.dumps(record, ensure_ascii=False) + '\n')
        count += 1

        if not checks['tiene_8_encabezados']:
            incompletos.append(
                f'    Ej.{i}: solo {checks["n_encabezados_presentes"]}/8 encabezados'
            )

    if incompletos:
        reporte_lines.append('  Ejercicios con encabezados faltantes:')
        reporte_lines.extend(incompletos)

    return count


# ══════════════════════════════════════════════════════════════════════
# PROCESAMIENTO PRINCIPAL
# ══════════════════════════════════════════════════════════════════════
def procesar_todo(entrada: str, archivo_salida: str):
    """Procesa un archivo o carpeta y genera el JSONL + reporte."""
    ruta = Path(entrada)
    reporte_lines = []
    total = 0
    archivos_ok = 0

    with open(archivo_salida, 'w', encoding='utf-8') as outfile:
        if ruta.is_file() and ruta.suffix == '.tex':
            archivos = [ruta]
        elif ruta.is_dir():
            archivos = sorted(ruta.rglob('*.tex'))
        else:
            print(f'Error: {entrada} no es un archivo .tex ni una carpeta válida.')
            return

        for archivo_tex in archivos:
            reporte_lines.append(f'\n[ARCHIVO] {archivo_tex.name}')
            n = procesar_archivo(archivo_tex, outfile, reporte_lines)
            reporte_lines.append(f'  → {n} ejercicios procesados')
            total += n
            if n > 0:
                archivos_ok += 1

    # Estadísticas finales
    stats = verificar_dataset(archivo_salida)

    resumen = [
        '',
        '=' * 60,
        'RESUMEN FINAL',
        '=' * 60,
        f'Archivos .tex procesados : {archivos_ok}',
        f'Total de ejercicios      : {total}',
        f'Con 8 encabezados ✓      : {stats["con_8_encabezados"]} ({stats["pct_8"]}%)',
        f'Con código Python ✗      : {stats["con_codigo"]}',
        f'Con LaTeX prohibido ✗    : {stats["con_latex_prohibido"]}',
        f'Con \\boxed{{...}} ✓       : {stats["con_boxed"]}',
        f'Dataset guardado en      : {archivo_salida}',
        '=' * 60,
    ]

    reporte_lines.extend(resumen)

    # Guardar reporte
    reporte_path = archivo_salida.replace('.jsonl', '_reporte.txt')
    with open(reporte_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(reporte_lines))

    # Imprimir resumen en consola
    print('\n'.join(resumen))
    print(f'\nReporte completo guardado en: {reporte_path}')

    # Mensaje final
    if stats["pct_8"] == 100 and stats["con_codigo"] == 0 and stats["con_latex_prohibido"] == 0:
        print('\n✓ Dataset PERFECTO. Listo para fine-tuning.')
    else:
        print('\n⚠ Revisa el reporte para los ejercicios que necesitan atención.')


def verificar_dataset(archivo_jsonl: str) -> dict:
    """Verifica estadísticas del dataset JSONL generado."""
    try:
        with open(archivo_jsonl, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        return {}

    total = len(lines)
    if total == 0:
        return {'total': 0, 'pct_8': 0, 'con_8_encabezados': 0,
                'con_codigo': 0, 'con_latex_prohibido': 0, 'con_boxed': 0}

    con_8 = con_codigo = con_latex = con_boxed = 0

    for line in lines:
        data = json.loads(line)
        asst = data['messages'][2]['content']
        checks = verificar_calidad(asst)
        if checks['tiene_8_encabezados']:
            con_8 += 1
        if checks['tiene_codigo_python']:
            con_codigo += 1
        if checks['tiene_latex_prohibido']:
            con_latex += 1
        if checks['tiene_boxed']:
            con_boxed += 1

    return {
        'total': total,
        'con_8_encabezados': con_8,
        'pct_8': round(100 * con_8 / total) if total else 0,
        'con_codigo': con_codigo,
        'con_latex_prohibido': con_latex,
        'con_boxed': con_boxed,
    }


# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    if len(sys.argv) >= 2:
        entrada = sys.argv[1]
        salida = sys.argv[2] if len(sys.argv) >= 3 else 'dataset_quimica_final.jsonl'
    else:
        entrada = '.'
        salida = 'dataset_quimica_final.jsonl'

    print(f'Procesando: {entrada}')
    print(f'Salida    : {salida}')
    print('-' * 60)
    procesar_todo(entrada, salida)