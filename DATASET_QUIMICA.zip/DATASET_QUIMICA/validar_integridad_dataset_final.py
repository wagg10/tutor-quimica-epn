﻿import json
from pathlib import Path
from collections import Counter

DATASET = Path("dataset_quimica_final.jsonl")
SALIDA_DIR = Path("evidencias_dataset_final")
SALIDA_DIR.mkdir(exist_ok=True)

REPORTE = SALIDA_DIR / "validacion_integridad_dataset_final.txt"

roles_validos = {"system", "user", "assistant"}
errores = []
contador_roles = Counter()
total_lineas = 0
total_mensajes = 0

with DATASET.open("r", encoding="utf-8") as f:
    for num_linea, linea in enumerate(f, start=1):
        total_lineas += 1
        linea = linea.strip()

        if not linea:
            errores.append(f"Línea {num_linea}: línea vacía.")
            continue

        try:
            obj = json.loads(linea)
        except json.JSONDecodeError as e:
            errores.append(f"Línea {num_linea}: JSON inválido -> {e}")
            continue

        if not isinstance(obj, dict):
            errores.append(f"Línea {num_linea}: el registro no es un objeto JSON.")
            continue

        if "messages" not in obj:
            errores.append(f"Línea {num_linea}: falta el campo 'messages'.")
            continue

        messages = obj["messages"]

        if not isinstance(messages, list):
            errores.append(f"Línea {num_linea}: el campo 'messages' no es una lista.")
            continue

        if len(messages) == 0:
            errores.append(f"Línea {num_linea}: la lista 'messages' está vacía.")
            continue

        for i, msg in enumerate(messages, start=1):
            total_mensajes += 1

            if not isinstance(msg, dict):
                errores.append(f"Línea {num_linea}, mensaje {i}: el mensaje no es un objeto.")
                continue

            if "role" not in msg:
                errores.append(f"Línea {num_linea}, mensaje {i}: falta el campo 'role'.")
                continue

            if "content" not in msg:
                errores.append(f"Línea {num_linea}, mensaje {i}: falta el campo 'content'.")
                continue

            role = msg["role"]
            content = msg["content"]

            if role not in roles_validos:
                errores.append(f"Línea {num_linea}, mensaje {i}: rol inválido '{role}'.")

            if not isinstance(content, str):
                errores.append(f"Línea {num_linea}, mensaje {i}: 'content' no es texto.")
            elif not content.strip():
                errores.append(f"Línea {num_linea}, mensaje {i}: 'content' está vacío.")

            contador_roles[role] += 1

reporte = []
reporte.append("=" * 70)
reporte.append("VALIDACIÓN DE INTEGRIDAD DEL DATASET FINAL")
reporte.append("=" * 70)
reporte.append(f"Archivo evaluado: {DATASET}")
reporte.append(f"Total de líneas evaluadas: {total_lineas}")
reporte.append(f"Total de mensajes revisados: {total_mensajes}")
reporte.append("")
reporte.append("Distribución de roles:")
for rol, cantidad in contador_roles.items():
    reporte.append(f"- {rol}: {cantidad}")
reporte.append("")
reporte.append(f"Total de errores encontrados: {len(errores)}")

if errores:
    reporte.append("")
    reporte.append("Detalle de errores:")
    for err in errores:
        reporte.append(f"- {err}")
else:
    reporte.append("")
    reporte.append("Resultado: dataset válido.")
    reporte.append("El archivo contiene ejemplos aptos para tokenización y entrenamiento supervisado.")

texto = "\n".join(reporte)
print(texto)
REPORTE.write_text(texto, encoding="utf-8")
